# Supported Question Types

Attack on Titan questions should be generated using one or more of the following formats.

Prefer memorable moments over obscure trivia.

---

## Character Recognition

Identify a character from an image.

Examples:

- What is this character's name?
- Which organization does this character belong to?
- What role does this character have?

Preferred assets:

- Character portraits
- Iconic poses
- Recognizable costumes

---

## Scene Recognition

Use an image or video from an iconic moment.

Examples:

- What happens after this scene?
- Which battle is this?
- What event is taking place?

Preferred assets:

- Major battles
- Emotional scenes
- Famous reveals
- Memorable confrontations

The scene should be recognizable without requiring the entire episode.

---

## Voice Recognition

Use a short voice clip.

Examples:

- Who is speaking?
- Which character said this quote?

Preferred assets:

- Emotional dialogue
- Famous quotes
- Character introductions
- Iconic screams

Avoid generic dialogue that multiple characters could have spoken.

---

## Titan Recognition

Identify Titans from images or videos.

Examples:

- What is the name of this Titan?
- Who is the current holder of this Titan?
- Which of the Nine Titans is this?

Prefer full Titan forms over partial close-ups.

---

## Story Mystery

Create questions about the major mysteries of Attack on Titan.

Examples:

- What is the origin of the Titans?
- Who gave Grisha Yeager the Attack Titan?
- What is hidden inside the basement?
- Why were the walls built?
- What is the truth about Marley?

Focus on important story revelations rather than minor details.

---

## Location Recognition

Identify important places.

Examples:

- What is the name of this district?
- Which wall is shown?
- Which city is this?
- Where does this event take place?

Preferred assets:

- Walls
- Districts
- Castles
- Marley
- Paradis Island
- Shiganshina
- Trost

---

## Organization Recognition

Questions about military branches and organizations.

Examples:

- Which regiment does this character belong to?
- Which organization uses this emblem?
- What is the name of this military branch?

Preferred assets:

- Uniforms
- Flags
- Emblems
- Cloaks
- Badges

---

## Ability Recognition

Questions about Titan abilities.

Examples:

- What ability is being used?
- Which Titan has this ability?
- Which power is shown?

Use visually distinctive abilities whenever possible.

---

## Relationship Questions

Questions about important relationships.

Examples:

- Who is this character's father?
- Who inherited this Titan?
- Who trained with this character?
- Who killed this character?

Prefer relationships that are central to the story.

---

## Motivation & Reasoning Questions

Create questions that test the player's understanding of why important events happened.

Focus on character motivations, decisions, and the underlying reasons behind major story events.

These questions should require understanding of the story rather than memorizing isolated facts.

Examples:

- Why did Eren manipulate his father?
- Why did Reiner destroy Wall Maria?
- Why did Zeke betray Marley?
- Why did Historia become queen?
- Why did Erwin continue the charge?
- Why did Grisha give Eren the Attack Titan?
- Why did Ymir choose to help Historia?

Preferred topics:

- Character motivations
- Moral dilemmas
- Strategic decisions
- Political choices
- Cause-and-effect relationships
- Major turning points

Avoid questions where multiple interpretations are equally valid.

The answer must be supported by canon and have one clear explanation.

Difficulty:

Easy:
- Obvious motivations of major characters.

Medium:
- Decisions requiring understanding of multiple events.

Hard:
- Motivations connected to major plot revelations or long-term story development.

## Validation

Every generated question must satisfy the following:

- The answer is canonically correct.
- The media clearly supports the question.
- The difficulty matches the intended level.
- The answer is unique.
- The asset is recognizable.
- The question creates an enjoyable "I know this!" moment.

### Motivation Validation

For motivation questions:

- The answer must be explicitly supported by the canon.
- Do not infer motives that were never confirmed.
- Do not generate opinion-based answers.
- If multiple interpretations are equally valid, reject the question.
- The answer should be explainable in one concise sentence.