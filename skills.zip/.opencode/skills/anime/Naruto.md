# Naruto Skill

## Purpose

This skill extends the Anime Question Design Skill.

It defines what Naruto fans remember and what should be prioritized when creating Naruto questions.

---

# Naruto Identity

Naruto is heavily driven by memorable characters, emotional scenes and iconic abilities.

Most enjoyable questions come from recognition rather than factual recall.

---

# What Naruto Fans Remember

Characters

- Naruto
- Sasuke
- Sakura
- Kakashi
- Itachi
- Madara
- Obito
- Pain
- Jiraiya
- Orochimaru
- Gaara
- Minato
- Tsunade
- Rock Lee
- Neji
- Shikamaru
- Hinata

Organizations

- Akatsuki
- Team 7
- Team 10
- Anbu

Villages

- Hidden Leaf
- Hidden Sand
- Hidden Mist
- Hidden Cloud
- Hidden Stone

Abilities

- Rasengan
- Chidori
- Sharingan
- Mangekyo Sharingan
- Rinnegan
- Byakugan
- Sage Mode
- Kurama Mode
- Susanoo
- Amaterasu
- Tsukuyomi
- Shadow Clone Jutsu

Weapons

- Kunai
- Shuriken
- Samehada

Summons

- Gamabunta
- Manda
- Katsuyu

Important Moments

- Naruto vs Sasuke
- Pain's attack
- Itachi's reveal
- Jiraiya's death
- Neji's death
- Madara entering the battlefield
- Rock Lee removing his weights
- Kakashi revealing Mangekyo Sharingan
- Naruto meeting Minato
- Naruto controlling Kurama

---

# Easy Difficulty

Prioritize:

- Main characters
- Akatsuki
- Sharingan
- Rasengan
- Chidori
- Kurama
- Hokage
- Famous fights

---

# Medium Difficulty

Prioritize:

- Sage Mode scenes
- Mangekyo abilities
- Supporting characters
- Summons
- Famous quotes
- Village symbols

---

# Hard Difficulty

Prioritize:

- Brief but memorable scenes
- Lesser-used jutsu
- Secondary characters
- Short appearances
- Advanced lore that dedicated fans commonly remember

Hard should still reward recognition.

Never rely on obscure facts.

---

# Things To Avoid

Avoid questions focused on:

- Filler episodes
- Episode numbers
- Production trivia
- Animation staff
- Voice actors
- Manga chapter numbers
- Extremely obscure lore

---

# Common Question Opportunities

Characters

- What is this character's name?

Abilities

- What is this jutsu?

Eyes

- Which dojutsu is shown?

Scene

- What happened after this moment?

Organization

- Which organization does this character belong to?

Village

- Which village is this?

Transformation

- What transformation is shown?

Quote

- Who said this quote?

Weapon

- What is this weapon called?