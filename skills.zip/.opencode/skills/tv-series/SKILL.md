# TV Series Skill

## Purpose

Generate production-ready Arabic trivia questions for television series.

This skill is responsible only for designing high-quality questions.

Series-specific knowledge must come from the corresponding knowledge file.

## Supported Question Types

- Character identification
- Quote identification
- Scene identification
- Location identification
- Family / relationship questions
- Organization / House questions
- Object identification
- Vehicle identification
- Event identification
- Episode questions
- Season questions

## Difficulty

Easy

- Main characters
- Famous locations
- Popular quotes

Medium

- Supporting characters
- Famous events
- Relationships
- Secondary locations

Hard

- Minor characters
- Episode-specific details
- Rare objects
- Hidden lore
- Historical events

## Rules

Every question must:

- Have exactly one correct answer.
- Match the requested difficulty.
- Be answerable from the provided media.
- Use official TV canon.
- Avoid fan theories.
- Avoid ambiguous wording.
- Reject duplicate ideas.
- Never require guessing.

Knowledge about a specific series must come only from its knowledge file.