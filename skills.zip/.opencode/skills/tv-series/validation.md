# TV Series Validation

Reject the question if:

- Multiple answers are possible.
- The media contains multiple important characters.
- The screenshot is blurry.
- The quote belongs to multiple characters.
- The answer depends on personal opinion.
- The scene requires context from another scene.
- The difficulty does not match.
- The answer is not visible enough.
- The question contains spoilers in Easy difficulty.

Accept only questions with one obvious answer.