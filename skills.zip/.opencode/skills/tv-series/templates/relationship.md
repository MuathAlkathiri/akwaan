# Relationship Questions

Examples

- ما علاقة هاتين الشخصيتين؟
- من والد هذه الشخصية؟
- من زوج هذه الشخصية؟
- لأي عائلة تنتمي هذه الشخصية؟

Rules

Relationships must be officially confirmed in the TV series.

Never use fan theories.