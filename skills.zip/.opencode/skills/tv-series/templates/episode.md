# Episode Questions

## Purpose

Design trivia questions about specific episodes, seasons, episode events, and story progression within a television series.

## Preferred Question Styles

- في أي موسم حدث هذا المشهد؟
- في أي حلقة حدث هذا الحدث؟
- ماذا حدث في نهاية هذه الحلقة؟
- أي شخصية ظهرت لأول مرة في هذه الحلقة؟
- ما الحدث الرئيسي في هذه الحلقة؟
- ما اسم هذه الحلقة؟
- في أي موسم ظهرت هذه الشخصية لأول مرة؟
- في أي حلقة غادرت هذه الشخصية؟

## Question Categories

- Episode identification
- Season identification
- First appearance
- Final appearance
- Episode ending
- Major episode event
- Season finale
- Season premiere
- Character introduction
- Character departure
- Location introduction
- Storyline progression

## Difficulty

### Easy

Use famous season finales, premieres, or iconic episodes.

Prefer questions asking for the season rather than an exact episode number.

### Medium

Use recognizable events and ask for the correct season or approximate story stage.

Exact episode questions are allowed when the event is memorable.

### Hard

Use episode-specific details, first appearances, final appearances, or exact episode titles.

Hard questions may require:

- Exact episode number
- Exact episode title
- Specific sequence of events
- Identifying the episode from a short scene

## Episode Title Rules

When asking for an episode title:

- Use the official episode title.
- Accept the official English title when no recognized Arabic title exists.
- Do not create translated titles.
- Do not use unofficial streaming-platform translations as the only answer.
- Add accepted answer variations when necessary.

## Media Rules

The selected image or video must:

- Come from the intended episode.
- Show a recognizable event.
- Avoid platform overlays containing the episode title.
- Avoid subtitles that reveal the answer.
- Avoid generic scenes repeated across many episodes.

## Validation Rules

Reject the question if:

- The scene appears in recaps across multiple episodes.
- The exact episode cannot be reliably verified.
- The question confuses production order with broadcast order.
- Different platforms use conflicting episode numbering.
- The episode title has multiple unofficial translations.
- The scene is too generic to identify the episode.
- The answer requires remembering an insignificant frame.
- More than one episode could reasonably match.

When exact numbering may vary, use the official original broadcast order.