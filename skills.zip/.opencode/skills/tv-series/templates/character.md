# Character Questions

Preferred styles:

- من هذه الشخصية؟
- ما اسم هذه الشخصية؟
- لأي مسلسل تنتمي هذه الشخصية؟

Images should:

- Clearly show the character.
- Avoid costumes that hide identity.
- Avoid multiple main characters.

Difficulty

Easy

Main characters.

Medium

Supporting characters.

Hard

Minor characters.