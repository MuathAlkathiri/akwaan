# Arabic Series Skill

## Purpose

Generate high-quality questions about Arabic TV series.

Questions must test the player's memory of the series.

Use visual, audio and story-based questions whenever possible.

Always follow the shared Question Writing Skill.

---

## Supported Question Types

Each series may support different question types depending on its content.

Common supported types include:

- Character Recognition
- Event Recognition
- Motivation
- Quote Recognition
- Relationship Recognition
- Location Recognition

Each series knowledge file defines the supported types.

---

## Media Priority

Prefer:

1. Images
2. Video clips
3. Audio
4. Text

Avoid text-only questions when a better visual asset exists.

---

## Validation

Reject questions if:

- They reveal the answer.
- They depend on non-canon information.
- Multiple answers could be correct.
- The media does not clearly support the question.
- The question duplicates another question.

Do not overuse Character Recognition.

Maximum:

20% of generated questions.

At least 50% of the questions must be based on:

- events
- battles
- dialogue
- strategies
- sequences
- relationships between multiple characters
- video clips

The goal is to test memory of the story, not face recognition.