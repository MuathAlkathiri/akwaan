# Image Generation

Generate one realistic frontal portrait.

Requirements:

- photorealistic
- symmetrical lighting
- neutral background
- looking at camera
- no text
- no logos
- no jersey emphasis
- chest-up portrait

The face should preserve recognizable features from BOTH people.

Do not create a split-face.

Do not create half-and-half edits.

Create one believable fused identity.

If one person dominates the blend, regenerate.

## Pair Quality

Choose pairs that create an enjoyable challenge.

Good pairs:

- Messi + Cristiano
- Neymar + Mbappé
- Zidane + Ronaldinho

Avoid:

- two nearly identical players
- two very obscure players
- two players with extremely similar faces

The pair itself should be entertaining before any image is generated.