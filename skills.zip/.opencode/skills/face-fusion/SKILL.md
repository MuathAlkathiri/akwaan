# Face Fusion Skill

## Purpose

Create enjoyable "Who are these two?" puzzles by blending two recognizable faces into one realistic portrait.

Players must identify both original people.

The objective is immediate recognition, not visual confusion.

---

# Gameplay

The player sees one merged face.

Question:

Who are these two people?

The correct answer consists of exactly two names.

---

# Workflow

1. Select two candidates.
2. Validate that both are widely recognizable.
3. Verify that they belong to the same category.
4. Generate the merged portrait.
5. Validate recognizability.
6. Reject weak blends.
7. Return the final image.

---

# Hard Rules

Never merge more than two people.

Never mix categories unless explicitly requested.

Never use obscure people.

Both faces must remain identifiable.

If either face becomes difficult to recognize, regenerate.