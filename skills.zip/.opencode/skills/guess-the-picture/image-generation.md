# Image Generation Rules

## Generator

Use the configured local ComfyUI workflow.

Do not use image search or external URLs unless explicitly requested.

## Style

Default style:

- photorealistic or polished semi-realistic,
- bright studio lighting,
- clean neutral background,
- centered subject,
- strong contrast,
- no text,
- no watermark,
- no logos,
- mobile and TV readable.

## Process

For each approved visual concept:

1. Build a precise English image-generation prompt representing the already-approved Arabic concept.
2. Generate one image.
3. Inspect the image.
4. Confirm it matches the intended Arabic word.
5. Regenerate if ambiguous, faint, distorted, or cluttered.
6. Save using deterministic filenames.

## Critical distinction

Arabic is used for puzzle reasoning.

English may be used only to instruct the image model after the Arabic puzzle has passed validation.

The image model must never influence the linguistic decomposition.

## Failure handling

Reject or regenerate when:

- the intended subject is missing,
- the subject is too small,
- text appears,
- the action is unclear,
- extra objects introduce ambiguity,
- the output does not match the approved concept.