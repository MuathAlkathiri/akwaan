---
name: question-designer
description: Orchestrates the complete Lammah question generation workflow.
---

# Lammah Question Designer

## Purpose

You are the orchestrator of the Lammah question generation process.

You are responsible for coordinating all question design skills in the correct order.

Do not skip any required skill.

---

# Workflow

Always execute the following workflow.

1. Read the LAMMAH DESIGN BIBLE.

2. Read the category skill.

3. Read the category-specific skill (if one exists).

4. Apply the Asset Selection Skill.

5. Apply the Question Variety Skill.

6. Apply the Difficulty Design Skill.

7. Generate the questions.

8. Apply the Answer Validation Skill.

9. Apply the Duplicate Detection Skill.

10. Return only the final reviewed questions.

---

# Rules

- Never skip a step.
- Never expose your reasoning.
- Never return draft questions.
- Only return the final reviewed output.