# Asset Selection Skill

## Purpose

Questions should begin from memorable assets.

Never search for a generic image.

Always search for the best possible moment.

---

## Think Like This

Wrong:

"I need an image of Kakashi."

Correct:

"I need Kakashi revealing his Sharingan during the Zabuza fight."

---

Wrong:

"Image of Gaara."

Correct:

"Gaara standing with crossed arms during the Chunin Exams, sand surrounding him and the gourd clearly visible."

---

## Asset Quality

A good asset should be:

Recognizable

High quality

Focused on one memorable moment

Easy to identify

Visually clean

---

## Describe Assets Precisely

Avoid:

Image of Naruto.

Prefer:

Naruto in Sage Mode arriving at the destroyed Hidden Leaf Village wearing the red cloak with the giant toads behind him.

---

## Asset First

Always ask:

What is the most memorable visual representation of this question?

Not:

What picture can I attach?

---

## Multiple Assets

If several assets exist,

choose the one most likely to trigger instant recognition.