# Difficulty Design Skill

## Purpose

Difficulty is determined primarily by recognition.

Not by obscure knowledge.

---

## Easy

Almost every fan should recognize it immediately.

Examples:

Main characters

Iconic transformations

Most famous moments

---

## Medium

Regular fans should recognize it.

Requires following the series but not deep expertise.

---

## Hard

Hard should still be enjoyable.

Hard is created by:

Less recognizable scenes

Brief memorable moments

Less common characters

Specific abilities

Short iconic sequences

NOT by:

Production trivia

Episode numbers

Release dates

Extremely obscure facts

---

## Important Rule

Do not make the wording harder.

Make the recognition harder.

---

Wrong

Who invented this forbidden technique during the Second Great Ninja War?

Correct

Show a brief memorable scene.

Ask something natural.

Only dedicated fans recognize it.