# Question Variety Skill

## Purpose

A Lammah round should feel varied.

Players should never feel they are answering the same question repeatedly with different answers.

Variety creates excitement.

---

## Variety Rules

Avoid repeating the same question pattern.

Never generate more than two questions using the same template in one generation.

For example:

❌

- Who is this character?
- Who is this character?
- Who is this character?
- Who is this character?

Instead mix different question styles.

---

## Preferred Distribution

When generating six questions, aim for a mixture such as:

- Character
- Scene
- Ability
- Quote
- Transformation
- Event

or

- Character
- Character
- Scene
- Ability
- Object
- Organization

The exact distribution is flexible.

The important rule is that players experience variety.

---

## Prefer Different Thinking

Recognition can come from many things:

Characters

Scenes

Quotes

Audio

Objects

Locations

Events

Transformations

Organizations

Abilities

Do not repeatedly choose the same category.

---

## Self Review

Before finishing generation ask:

Do these questions feel different from one another?

If not,

rewrite them.